package com.demo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.demo.pages.CartPage;
import com.demo.pages.CheckoutInformationPage;
import com.demo.pages.CheckoutOverviewPage;
import com.demo.pages.InventoryPage;
import com.demo.pages.LoginPage;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SauceDemoShoppingTest {
    private static final String LOGIN_PAGE_URL = "https://www.saucedemo.com/";
    private static final String VALID_USERNAME = "standard_user";
    private static final String VALID_PASSWORD = "secret_sauce";

    private WebDriver webDriver;

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        webDriver = new ChromeDriver();
        webDriver.manage().window().maximize();
    }

    @Test(description = "User can add an item, continue shopping, and reach checkout overview")
    public void userCanAddItemAndProceedToCheckoutOverview() {
        LoginPage loginPage = new LoginPage(webDriver).open(LOGIN_PAGE_URL);
        loginPage.enterUsername(VALID_USERNAME);
        loginPage.enterPassword(VALID_PASSWORD);
        InventoryPage inventoryPage = loginPage.clickLogin();

        inventoryPage.addBackpackToCart();
        CartPage cartPage = inventoryPage.openShoppingCart();
        Assert.assertTrue(cartPage.isCartDisplayed(), "The shopping cart should be displayed.");
        Assert.assertTrue(cartPage.containsBackpack(), "The Sauce Labs Backpack should be in the cart.");

        inventoryPage = cartPage.continueShopping();
        Assert.assertTrue(inventoryPage.isDashboardDisplayed(), "Continue Shopping should return to the inventory dashboard.");

        cartPage = inventoryPage.openShoppingCart();
        CheckoutInformationPage checkoutInformationPage = cartPage.clickCheckout();
        Assert.assertTrue(checkoutInformationPage.isCheckoutInformationDisplayed(),
                "Checkout: Your Information should be displayed.");

        checkoutInformationPage.enterCustomerInformation("Test", "Customer", "12345");
        CheckoutOverviewPage checkoutOverviewPage = checkoutInformationPage.clickContinue();
        Assert.assertTrue(checkoutOverviewPage.isCheckoutOverviewDisplayed(),
                "Checkout: Overview should be displayed.");
    }

    @AfterMethod
    public void tearDown() {
        if (webDriver != null) {
            
            webDriver.quit();
        }
    }
}