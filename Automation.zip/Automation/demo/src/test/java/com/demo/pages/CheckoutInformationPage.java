package com.demo.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CheckoutInformationPage {
    private final WebDriver webDriver;
    private final WebDriverWait webDriverWait;
    private final By checkoutInformationContainer = By.id("checkout_info_container");
    private final By firstNameInput = By.id("first-name");
    private final By lastNameInput = By.id("last-name");
    private final By postalCodeInput = By.id("postal-code");
    private final By continueButton = By.id("continue");

    public CheckoutInformationPage(WebDriver webDriver) {
        this.webDriver = webDriver;
        this.webDriverWait = new WebDriverWait(webDriver, Duration.ofMinutes(1));
    }

    public boolean isCheckoutInformationDisplayed() {
        return webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(checkoutInformationContainer)).isDisplayed();
    }

    public void enterCustomerInformation(String firstName, String lastName, String postalCode) {
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(firstNameInput)).sendKeys(firstName);
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(lastNameInput)).sendKeys(lastName);
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(postalCodeInput)).sendKeys(postalCode);
    }

    public CheckoutOverviewPage clickContinue() {
        webDriverWait.until(ExpectedConditions.elementToBeClickable(continueButton)).click();
        return new CheckoutOverviewPage(webDriver);
    }
}
