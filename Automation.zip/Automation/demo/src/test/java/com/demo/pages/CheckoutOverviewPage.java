package com.demo.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CheckoutOverviewPage {
    private final WebDriverWait webDriverWait;
    private final By checkoutOverviewContainer = By.id("checkout_summary_container");

    public CheckoutOverviewPage(WebDriver webDriver) {
        this.webDriverWait = new WebDriverWait(webDriver, Duration.ofMinutes(1));
    }

    public boolean isCheckoutOverviewDisplayed() {
        return webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(checkoutOverviewContainer)).isDisplayed();
    }
}
