package com.demo.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {
    private final WebDriver webDriver;
    private final WebDriverWait webDriverWait;

    private final By usernameInput = By.id("user-name");
    private final By passwordInput = By.id("password");
    private final By loginButton = By.id("login-button");

    public LoginPage(WebDriver webDriver) {
        this.webDriver = webDriver;
        this.webDriverWait = new WebDriverWait(webDriver, Duration.ofMinutes(1));
    }

    public LoginPage open(String loginPageUrl) {
        webDriver.get(loginPageUrl);
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(usernameInput));
        return this;
    }

    public void enterUsername(String username) {
        WebElement usernameField = webDriverWait.until(
                ExpectedConditions.visibilityOfElementLocated(usernameInput));
        usernameField.sendKeys(username);
    }

    public void enterPassword(String password) {
        WebElement passwordField = webDriverWait.until(
                ExpectedConditions.visibilityOfElementLocated(passwordInput));
        passwordField.sendKeys(password);
    }

    public InventoryPage clickLogin() {
        webDriverWait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();
        return new InventoryPage(webDriver);
    }
}
