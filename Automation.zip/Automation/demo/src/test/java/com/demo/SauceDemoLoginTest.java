package com.demo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.demo.pages.InventoryPage;
import com.demo.pages.LoginPage;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SauceDemoLoginTest {
    private static final String LOGIN_PAGE_URL = "https://www.saucedemo.com/";
    private static final String VALID_USERNAME = "standard_user";
    private static final String VALID_PASSWORD = "secret_sauce";

    private WebDriver webDriver;

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        webDriver = new ChromeDriver();
        webDriver.manage().window().maximize();
    }

    @Test(description = "Valid user can log in and view the inventory dashboard")
    public void validUserCanLoginAndViewDashboard() {
        LoginPage loginPage = new LoginPage(webDriver).open(LOGIN_PAGE_URL);
        loginPage.enterUsername(VALID_USERNAME);
        loginPage.enterPassword(VALID_PASSWORD);

        InventoryPage inventoryPage = loginPage.clickLogin();

        Assert.assertTrue(inventoryPage.isDashboardDisplayed(),
                "The inventory dashboard should be displayed after a successful login.");
    }

    @AfterMethod
    public void tearDown() {
        if (webDriver != null) {
            webDriver.quit();
        }
    }
}