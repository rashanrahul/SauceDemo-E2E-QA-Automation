package com.demo.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class InventoryPage {
    private final WebDriver webDriver;
    private final WebDriverWait webDriverWait;
    private final By inventoryContainer = By.id("inventory_container");
    private final By backpackAddToCartButton = By.id("add-to-cart-sauce-labs-backpack");
    private final By shoppingCartLink = By.className("shopping_cart_link");

    public InventoryPage(WebDriver webDriver) {
        this.webDriver = webDriver;
        this.webDriverWait = new WebDriverWait(webDriver, Duration.ofMinutes(1));
    }

    public boolean isDashboardDisplayed() {
        return webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(inventoryContainer)).isDisplayed();
    }

    public void addBackpackToCart() {
        webDriverWait.until(ExpectedConditions.elementToBeClickable(backpackAddToCartButton)).click();
    }

    public CartPage openShoppingCart() {
        webDriverWait.until(ExpectedConditions.elementToBeClickable(shoppingCartLink)).click();
        return new CartPage(webDriver);
    }
}
