package com.demo.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CartPage {
    private final WebDriver webDriver;
    private final WebDriverWait webDriverWait;
    private final By cartContainer = By.id("cart_contents_container");
    private final By backpackItem = By.id("item_4_title_link");
    private final By continueShoppingButton = By.id("continue-shopping");
    private final By checkoutButton = By.id("checkout");

    public CartPage(WebDriver webDriver) {
        this.webDriver = webDriver;
        this.webDriverWait = new WebDriverWait(webDriver, Duration.ofMinutes(1));
    }

    public boolean isCartDisplayed() {
        return webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(cartContainer)).isDisplayed();
    }

    public boolean containsBackpack() {
        return webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(backpackItem)).isDisplayed();
    }

    public InventoryPage continueShopping() {
        webDriverWait.until(ExpectedConditions.elementToBeClickable(continueShoppingButton)).click();
        return new InventoryPage(webDriver);
    }

    public CheckoutInformationPage clickCheckout() {
        webDriverWait.until(ExpectedConditions.elementToBeClickable(checkoutButton)).click();
        return new CheckoutInformationPage(webDriver);
    }
}
